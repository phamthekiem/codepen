<?php

require_once( 'class-itsec-ssl.php' );

ITSEC_SSL::activate();
