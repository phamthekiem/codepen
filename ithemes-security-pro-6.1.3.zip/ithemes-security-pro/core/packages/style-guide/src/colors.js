export const PRIMARYS = Object.freeze( [
	/*'#0083E3',
	'#FFCE00',
	'#52c551',
	'#7ABEED',*/
	'#e67e22', // carrot
	'#2ecc71', // emerald
	'#3498db', // peter river
	'#e74c3c', // alizarin
	'#8e44ad', // wisteria
	'#1abc9c', // turquoise
	'#2c3e50', // midnight blue
] );
