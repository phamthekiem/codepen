White
==================

Thank for Downloading White WordPress Theme. This theme comes with plenty of features. All the features are very easy to use and Self Documented. A Detailed Documentation for this theme will be available soon.

Installation
---------------

1. Upload the File white.zip to Appearance > Themes > Add New > Upload.
2. Install & Activate. Done. :)
3. Good luck!


Copyright/License
-----------------

White WordPress Theme, Copyright 2014, Rohit Tripathi
White is distributed under the terms of the GNU GPL

Copyrights/Licenses for Resources Used in this Theme
----------------------------------------------------

1. Underscores Framework, Copyright 2013 Automattic
	GPL v2.0 License
	http://underscores.me
	
2. Redux Framework, Copyright 2014 Redux Framework
	GPL v2.0 License
	http://reduxframework.com
		
3. Bootstrap 3.1.1, Copyright 2010 Twitter
	MIT License
	http://getbootstrap.com
	
4. BxSlider, Copyright 2013 Steven Wanderski 
	MIT License
	http://bxslider.com
	
5. Aleo Font, Copyright 2013 Alessio Laiso
	SIL Open Font License 1.1
	http://www.fontsquirrel.com/fonts/aleo 
	
6. Font Awesome Copyright 2014, Dave Gandy
	MIT License	
	http://fortawesome.github.io/Font-Awesome/
	
7. Transit.js Copyright 2011-14 Rico Sta Cruz
	MIT License	
	http://ricostacruz.com/jquery.transit/
	
All Other Images(Social Icons) and JS files, Have been Created by me for the purpose of this theme, and fall under this theme's GPL 3.0 License.


Screenshot & Default Images
---------------------------

Follwing Images are all under Public Domain, CC0. Hence, No Copyrights.

License URI ->

	i) http://pixabay.com/static/uploads/photo/2014/07/25/08/48/sunset-401541_150.jpg
	ii) http://pixabay.com/static/uploads/photo/2014/07/10/10/20/golden-gate-bridge-388917_150.jpg
	iii) http://pixabay.com/static/uploads/photo/2014/08/11/11/05/oriental-pearl-tower-415474_150.jpg
	iv) http://pixabay.com/static/uploads/photo/2014/07/01/12/37/lifeguard-381240_150.jpg
	v) http://pixabay.com/static/uploads/photo/2014/07/01/12/35/taxi-cab-381233_150.jpg
	vi) http://pixabay.com/static/uploads/photo/2014/07/01/12/36/smartphone-381237_150.jpg
	vii) http://pixabay.com/en/photographer-tourist-snapshot-407068/
	viii) http://pixabay.com/en/milsons-point-sydney-australia-330400/
	ix) http://unsplash.com/post/94204091269/download-by-elaine-li
	x) http://pixabay.com/en/manhattan-new-york-city-407703/
	xi) http://pixabay.com/en/notebook-workplace-desk-iphone-336634/ 